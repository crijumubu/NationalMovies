export class product {
    constructor(id, productName, detail, price, discount, description, image) {
        this.id = id;
        this.productName = productName;
        this.detail = detail;
        this.price = price;
        this.discount = discount;
        this.description = description;
        this.image = image;
    }
}